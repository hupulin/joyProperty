package com.joy.property.shop;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.jinyi.ihome.infrastructure.MessageToBulk;
import com.jinyi.ihome.module.newshop.AddCarParam;
import com.jinyi.ihome.module.newshop.BlankParam;
import com.jinyi.ihome.module.newshop.CategoryTo;
import com.jinyi.ihome.module.newshop.GoodsListParam;
import com.jinyi.ihome.module.newshop.MyShopCarTo;
import com.jinyi.ihome.module.newshop.ShopListDetailTo;
import com.joy.common.api.ApiClientBulk;
import com.joy.common.api.HttpCallback;
import com.joy.common.api.NewShopApi;
import com.joy.property.R;
import com.joy.property.base.BaseActivity;
import com.joyhome.nacity.app.photo.util.PublicWay;
import com.joy.property.shop.adapter.GoodsListAdapter;
import com.joy.property.shop.shoputil.CarNumberUtil;
import com.joyhome.nacity.app.util.CustomDialogFragment;
import com.joyhome.nacity.app.util.ViewPagerCompat;
import java.util.ArrayList;
import java.util.List;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by xz on 2016/7/16.
 **/
public class ShopMoreType extends BaseActivity implements View.OnClickListener {
    private List<ShopListDetailTo>detailList=new ArrayList<>();
    private TextView salas;
    private TextView price;
    private TextView newGoods;
    private ListView listView;
    private GoodsListAdapter adapter;
    private PullToRefreshListView pullListView;
    private int pagerIndex=1;
    private int currentSelect=0;
    private boolean highPrice;
    private ImageView priceIcon;
    private List<CategoryTo> categoryList=new ArrayList<>();
    private TextView title;
    private CategoryTo category;
    private TextView carNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_more_type);
        initView();
        setView();
        getSalesData("");
        refreshData();
        getType();
        enterShop();
        getMyShopCar();
        enterGoodsDetail();

    }



    private void refreshData() {
        pullListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {
            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                pagerIndex = 1;
                if (currentSelect == 0) {
                    getSalesData("");
                } else if (currentSelect == 1) {
                    initData("");
                } else if (currentSelect == 2) {
                    getNewGoods("");
                }
            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                pagerIndex++;
                if (currentSelect ==0) {
                    getSalesData(pagerIndex + "");
                } else if (currentSelect == 1) {
                    initData(pagerIndex + "");
                } else if (currentSelect == 2) {
                    getNewGoods(pagerIndex + "");
                }
            }
        });
    }


    private void initView() {
        salas = (TextView) findViewById(R.id.sales);
        price = (TextView) findViewById(R.id.price);
        newGoods = (TextView) findViewById(R.id.newGoods);
        priceIcon = (ImageView) findViewById(R.id.priceIcon);
        salas.setOnClickListener(this);
        price.setOnClickListener(this);
        newGoods.setOnClickListener(this);
        pullListView = (PullToRefreshListView) findViewById(R.id.listView);
        pullListView.setMode(PullToRefreshBase.Mode.BOTH);
        listView= pullListView.getRefreshableView();
        listView.setDividerHeight(0);
        adapter = new GoodsListAdapter(getThisContext());
        adapter.setList(detailList);
        listView.setAdapter(adapter);
        findViewById(R.id.shop_type).setOnClickListener(this);
        title = (TextView) findViewById(R.id.title);
        carNumber = (TextView) findViewById(R.id.carNumber);
        findViewById(R.id.back).setOnClickListener(this);
        findViewById(R.id.shop_car).setOnClickListener(this);
    }
    private void setView() {
        CarNumberUtil.getCarNumber(mUserHelperBulk.getSid(),getThisContext(),carNumber);
        category = (CategoryTo) getIntent().getSerializableExtra("category");
        title.setText(category.getName());
    }
    private void initData(String index) {
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        final CustomDialogFragment dialogFragment = new CustomDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), "");
        GoodsListParam param = new GoodsListParam();
        param.setCategoryId(category.getId());
        param.setCurrentPage(index);
        param.setPageSize("20");
        param.setCommunityId(mUserHelperBulk.getUserInfoTo().getApartmentSid());
        if (highPrice)
            param.setPriceSort("desc");
        else
            param.setPriceSort("asc");

        api.getMoreSingle(param, new HttpCallback<MessageToBulk<List<ShopListDetailTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<ShopListDetailTo>> msg, Response response) {
                dialogFragment.dismiss();
                setListComplement();

                if (msg.getCode() == 0) {
                    if ("".equals(index))
                        detailList.clear();
                    if (msg.getGoodsApiVoList() != null) {
                        detailList.addAll(msg.getGoodsApiVoList());
                        if (detailList.size() > 0&&!getIntent().getBooleanExtra("isAdEnter",false))
                            title.setText(detailList.get(0).getCategoryName());
                    }
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void failure(RetrofitError error) {
                setListComplement();
                dialogFragment.dismiss();
            }
        });
    }

    private void getSalesData(String index) {
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        final CustomDialogFragment dialogFragment = new CustomDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), "");
        GoodsListParam param = new GoodsListParam();
        param.setCurrentPage(index);
        param.setPageSize("20");
        param.setCommunityId(mUserHelperBulk.getUserInfoTo().getApartmentSid());
        param.setCategoryId(category.getId());
        System.out.println(param + "param");
        api.getBySaleSingle(param, new HttpCallback<MessageToBulk<List<ShopListDetailTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<ShopListDetailTo>> msg, Response response) {
                dialogFragment.dismiss();
                setListComplement();
                if (msg.getCode() == 0) {
                    if ("".equals(index)) {
                        detailList.clear();
                    }
                    System.out.println(msg.getGoodsApiVoList() + "______________-");
                    if (msg.getGoodsApiVoList() != null)
                        detailList.addAll(msg.getGoodsApiVoList());
                    adapter.notifyDataSetChanged();

                }
            }

            @Override
            public void failure(RetrofitError error) {
                dialogFragment.dismiss();
                setListComplement();
            }
        });
    }
    private void getNewGoods(String index) {
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        final CustomDialogFragment dialogFragment = new CustomDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), "");
        GoodsListParam param = new GoodsListParam();
        param.setCurrentPage(index);
        param.setPageSize("20");
        param.setCommunityId(mUserHelperBulk.getUserInfoTo().getApartmentSid());
        param.setCategoryId(category.getId());
        api.getByNewGoodsSingle(param, new HttpCallback<MessageToBulk<List<ShopListDetailTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<ShopListDetailTo>> msg, Response response) {
                dialogFragment.dismiss();
                setListComplement();
                System.out.println(msg.getGoodsApiVoList());
                if (msg.getCode() == 0) {
                    if ("".equals(index)) {
                        detailList.clear();
                    }
                    if (msg.getGoodsApiVoList() != null)
                        detailList.addAll(msg.getGoodsApiVoList());
                    adapter.notifyDataSetChanged();

                }
            }

            @Override
            public void failure(RetrofitError error) {
                dialogFragment.dismiss();
                System.out.println(error+"error");
                setListComplement();
            }
        });
    }
    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.back:
                onBackPressed();
                break;
            case R.id.sales:
                currentSelect=0;
                getSalesData("");
                salas.setTextColor(Color.parseColor("#4fb2d6"));
                price.setTextColor(Color.parseColor("#353535"));
                newGoods.setTextColor(Color.parseColor("#353535"));
                pagerIndex=1;
                break;
            case R.id.price:
                if (currentSelect==1) {
                    if (highPrice) {
                        highPrice = false;
                        priceIcon.setBackgroundResource(R.drawable.shop_price_up);
                    }
                    else {
                        highPrice = true;
                        priceIcon.setBackgroundResource(R.drawable.shop_price_down);
                    }
                }
                    initData("");
                currentSelect=1;
                salas.setTextColor(Color.parseColor("#353535"));
                price.setTextColor(Color.parseColor("#4fb2d6"));
                newGoods.setTextColor(Color.parseColor("#353535"));
                pagerIndex=1;
                break;
            case R.id.newGoods:
                currentSelect=2;
                salas.setTextColor(Color.parseColor("#353535"));
                price.setTextColor(Color.parseColor("#353535"));
                newGoods.setTextColor(Color.parseColor("#4fb2d6"));
                getNewGoods("");
                pagerIndex=1;
                break;
            case R.id.shop_type:
                showType();
                break;
            case R.id.iv_back:
                onBackPressed();
                break;
            case R.id.shop_car:
                startActivity(new Intent(getThisContext(), ShoppingCarActivity.class));
                goToAnimation(1);
                break;

        }
    }
    public void setListComplement(){
        pullListView.onRefreshComplete();
    }
    public void showType(){
        LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View contentView = inflater.inflate(R.layout.dialog_shop_type, null);

        GridLayout channelGorup = (GridLayout)contentView. findViewById(R.id.channel_group);
        for(CategoryTo shopListTo:categoryList){
            View linearLayout= LinearLayout.inflate(getThisContext(), R.layout.shop_type_pup_item, null);
            TextView channelName = (TextView) linearLayout.findViewById(R.id.channel_name);
            channelName.setText(shopListTo.getName());
            WindowManager wm = (WindowManager)getThisContext().getSystemService(getThisContext().WINDOW_SERVICE);
            Display display = wm.getDefaultDisplay();
            int mWidth=display.getWidth();
            int marginLeft =(int)(mWidth*0.0805);
            int marginBottom =(int)(mWidth*0.0486);
            int  width = (int)(mWidth*0.2013);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = width;
            lp.height = ViewPagerCompat.LayoutParams.WRAP_CONTENT;
            lp.setMargins(marginLeft, 0, 0, marginBottom);
            linearLayout.setLayoutParams(lp);
            linearLayout.setOnClickListener(v -> {
                startActivity(new Intent(getThisContext(),ShopMoreType.class));
                finish();
            });
            channelGorup.addView(linearLayout);
        }

        View view=findViewById(R.id.layout_title);
        contentView.setFocusable(true);
        contentView.setFocusableInTouchMode(true);

        PopupWindow popupWindow = new PopupWindow(contentView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setFocusable(true);
        contentView.findViewById(R.id.pup_layout).setOnClickListener(v ->popupWindow.dismiss());
        popupWindow.setOutsideTouchable(true);
        popupWindow.showAsDropDown(view);
    }
    private void getType() {
        NewShopApi api= ApiClientBulk.create(NewShopApi.class);
        BlankParam param=new BlankParam();

        api.getCategory(param, new HttpCallback<MessageToBulk<List<CategoryTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<CategoryTo>> msg, Response response) {
                if (msg.getCode() == 0) {
                    categoryList.clear();

                    categoryList.addAll(msg.getGoodsCategoryList());


                }
            }

            @Override
            public void failure(RetrofitError error) {

            }
        });
    }
    public void addCar(String goodsId){
        NewShopApi api=ApiClientBulk.create(NewShopApi.class);
        AddCarParam param=new AddCarParam();
        param.setGoodsId(goodsId);
        param.setUserId(mUserHelperBulk.getSid());
        param.setNum("1");
        param.setSpecificationsId(detailList.get(0).getGoodsSpecificationsList().get(0).getSpecificationsId());
        param.setSpecificationsName(detailList.get(0).getGoodsSpecificationsList().get(0).getSpecificationsName());
        param.setGoodsType("0");
        System.out.println(detailList + "");
        System.out.println(param+"param");
        final CustomDialogFragment dialogFragment = new CustomDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), "");
        api.addCar(param, new HttpCallback<MessageToBulk>(getThisContext()) {
            @Override
            public void success(MessageToBulk msg, Response response) {
                dialogFragment.dismiss();
                System.out.println( msg.getMessage());
                if (msg.getCode()==0) {
                    ToastShowLong(getThisContext(), "加入购物车成功");
                    carNumber.setText(msg.getTotal() + "");
                }else
                    ToastShowLong(getThisContext(),msg.getMessage());
            }

            @Override
            public void failure(RetrofitError error) {
                dialogFragment.dismiss();

            }
        });
    }
    public void getMyShopCar(){

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        goToAnimation(2);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==KeyEvent.KEYCODE_BACK)
            onBackPressed();
        return super.onKeyDown(keyCode, event);
    }
    private void enterShop() {
        adapter.setCanEnterShopClickListener((shopSid, name,saleType) -> {
            Intent intent;
            if ("自营商品".equals(saleType))
                intent = new Intent(getThisContext(), SelfShopActivity.class);
            else
                intent = new Intent(getThisContext(), MerchantShopActivity.class);
            intent.putExtra("ShopSid", shopSid);
            System.out.println(shopSid + "sid"+name);
            intent.putExtra("ShopName", name);
            startActivity(intent);
            goToAnimation(1);
        });
        adapter.setAddCarClickListener((goodsId, name) -> addCar(goodsId));
    }
    private void enterGoodsDetail() {
        adapter.setEnterGoodsDetailListener(new GoodsListAdapter.EnterGoodsDetailListener() {
            @Override
            public void OnEnterDetailClick(String goodsSid,boolean isActivity) {
                Intent intent = new Intent(getThisContext(), SideGoodsDetailActivity.class);
                intent.putExtra("GoodsSid", goodsSid);
                intent.putExtra("ActivityGoods",isActivity);
                startActivity(intent);
            }
        });
    }



}
