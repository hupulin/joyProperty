package com.joy.property.common.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.List;

/**
 * Created by Admin on 2015-04-27
 */
public class CommonFragmentPagerAdapter extends FragmentStatePagerAdapter {
    private List<Fragment>  fragmentList;
    public CommonFragmentPagerAdapter(FragmentManager fm ,List<Fragment> list) {
        super(fm);
        this.fragmentList = list;
    }

    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentList.size();
    }
}
