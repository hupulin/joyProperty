package com.joy.property.constant;

/**
 * Created by Admin on 2015-03-14
 */
public class Constant {

    public final static int RESULT_SDCARD = 811;
    public final static int RESULT_CAMERA = 10011;
    public final static int RESULT_SERVICE_TYPE_CANCEL = 411;
    public final static int BULK_CODE = 2012;
    public final static int REG_CODE = 101;
    public final static int MAIN_CODE = 201;
    public final static int HOUSE_CODE = 202;
    public final static int NEIGHBORTHOOD_CODE = 2012;
    public final static int COMMENT_CODE = 2013;
}
