package com.joy.property.neighborhood;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.joy.property.base.BaseActivity;


/**
 * Created by xz on 2016/10/9.
 **/
public class NeighborReportActivity extends BaseActivity implements View.OnClickListener {

    private ImageView reportIcon1;
    private ImageView reportIcon2;
    private ImageView reportIcon3;
    private ImageView reportIcon4;
    private ImageView reportIcon5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  setContentView(R.layout.activity_neighbor_report);
        initView();
    }

    private void initView() {
//        findViewById(R.id.reportClick1).setOnClickListener(this);
//        findViewById(R.id.reportClick2).setOnClickListener(this);
//        findViewById(R.id.reportClick3).setOnClickListener(this);
//        findViewById(R.id.reportClick4).setOnClickListener(this);
//        findViewById(R.id.reportClick5).setOnClickListener(this);
//        reportIcon1 = (ImageView) findViewById(R.id.reportIcon1);
//        reportIcon2 = (ImageView) findViewById(R.id.reportIcon2);
//        reportIcon3 = (ImageView) findViewById(R.id.reportIcon3);
//        reportIcon4 = (ImageView) findViewById(R.id.reportIcon4);
//        reportIcon5 = (ImageView) findViewById(R.id.reportIcon5);
    }

    @Override
    public void onClick(View v) {
switch (v.getId()){
//    case R.id.reportClick1:
//        reportIcon1.setBackgroundResource(R.drawable.report_select_icon);
//        reportIcon2.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon3.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon4.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon5.setBackgroundResource(R.drawable.report_unselect_icon);
//        break;
//    case R.id.reportClick2:
//        reportIcon1.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon2.setBackgroundResource(R.drawable.report_select_icon);
//        reportIcon3.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon4.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon5.setBackgroundResource(R.drawable.report_unselect_icon);
//        break;
//    case R.id.reportClick3:
//        reportIcon1.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon2.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon3.setBackgroundResource(R.drawable.report_select_icon);
//        reportIcon4.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon5.setBackgroundResource(R.drawable.report_unselect_icon);
//        break;
//    case R.id.reportClick4:
//        reportIcon1.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon2.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon3.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon4.setBackgroundResource(R.drawable.report_select_icon);
//        reportIcon5.setBackgroundResource(R.drawable.report_unselect_icon);
//        break;
//    case R.id.reportClick5:
//        reportIcon1.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon2.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon3.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon4.setBackgroundResource(R.drawable.report_unselect_icon);
//        reportIcon5.setBackgroundResource(R.drawable.report_select_icon);
//        break;

}
    }
}
