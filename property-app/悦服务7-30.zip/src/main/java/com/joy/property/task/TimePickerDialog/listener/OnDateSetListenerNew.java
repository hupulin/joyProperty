package com.joy.property.task.TimePickerDialog.listener;

import com.joy.property.task.TimePickerDialog.TimePickerExpect;

/**
 * Created by usb on 2017/6/9.
 */

public interface OnDateSetListenerNew {
    void onDateSet(TimePickerExpect timePickerView, long millseconds) ;



}
