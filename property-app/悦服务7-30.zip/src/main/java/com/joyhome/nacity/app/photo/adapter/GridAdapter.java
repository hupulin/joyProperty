package com.joyhome.nacity.app.photo.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.joy.property.R;
import com.joyhome.nacity.app.photo.util.Bimp;

/**
 * Created by usb on 2017/5/12.
 */
@SuppressLint("HandlerLeak")
public class GridAdapter extends BaseAdapter {
    private LayoutInflater inflater;
    private int selectedPosition = -1;
    private boolean shape;
    private Context mContext;
    public Thread thread;

    public boolean isShape() {
        return shape;
    }

    public void setShape(boolean shape) {
        this.shape = shape;
    }

    public GridAdapter(Context context) {
        inflater = LayoutInflater.from(context);
        mContext = context;
    }

    public void update() {
        loading();
    }

    public int getCount() {
        if (Bimp.tempSelectBitmap.size() == 9) {
            return 9;
        }
        return (Bimp.tempSelectBitmap.size() + 1);
    }

    public Object getItem(int arg0) {
        return null;
    }

    public long getItemId(int arg0) {
        return 0;
    }

    public void setSelectedPosition(int position) {
        selectedPosition = position;
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.neighbor_published_grida, parent, false);
            holder = new ViewHolder();
            holder.image = (ImageView) convertView.findViewById(R.id.item_grid_image);
            holder.deleteImage=(ImageView) convertView.findViewById(R.id.deleteImage);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        holder.image.setLayoutParams(getLayoutParams());

        if (position == Bimp.tempSelectBitmap.size()) {
            holder.image.setImageBitmap(BitmapFactory.decodeResource(mContext.getResources(), R.drawable.post_add_pic_ic));
            holder.deleteImage.setVisibility(View.GONE);
            if (position == 9) {
                holder.image.setVisibility(View.GONE);
                holder.deleteImage.setVisibility(View.GONE);
            }
        } else {

            holder.image.setImageBitmap(Bimp.tempSelectBitmap.get(position).getBitmap());
            holder.deleteImage.setOnClickListener(v -> {
                Bimp.tempSelectBitmap.remove(position);
                notifyDataSetChanged();
            });
        }

        return convertView;
    }

    public RelativeLayout.LayoutParams getLayoutParams() {

        int mScreenWidth =getScreenWidthPixels(mContext);

        int mWidth = (mScreenWidth - 140) / 4;

        return new RelativeLayout.LayoutParams(mWidth, mWidth);
    }

    public class ViewHolder {
        public ImageView image;
        public ImageView deleteImage;
    }

    Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    notifyDataSetChanged();
                    break;
            }
            super.handleMessage(msg);
        }
    };

    public void loading() {
        thread = new Thread(new Runnable() {
            public void run() {
                while (isShape()) {
                    if (Bimp.max == Bimp.tempSelectBitmap.size()) {
                        Message message = new Message();
                        message.what = 1;
                        handler.sendMessage(message);
                        break;
                    } else {
                        Bimp.max += 1;
                        Message message = new Message();
                        message.what = 1;
                        handler.sendMessage(message);
                    }
                }
            }
        });
        thread.start();
    }
    public int getScreenWidthPixels(Context context) {
        DisplayMetrics metrics = new DisplayMetrics();
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        wm.getDefaultDisplay().getMetrics(metrics);
        return metrics.widthPixels;
    }
}
