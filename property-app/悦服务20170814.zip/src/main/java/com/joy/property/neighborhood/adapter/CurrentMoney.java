package com.joy.property.neighborhood.adapter;

/**
 * Created by xz on 2016/11/1.
 */
public class CurrentMoney {
    private int curMoney;
    public Boolean CurrentMoney(int curMoney) {
        if (curMoney == 10)
            return true;
        else
            return false;
    }

}
