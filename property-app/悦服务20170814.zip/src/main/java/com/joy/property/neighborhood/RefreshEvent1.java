package com.joy.property.neighborhood;

/**
 * Created by xz on 2016/4/6.
 */
public class RefreshEvent1 {
    private String mMsg;
    public RefreshEvent1(String msg) {
        // TODO Auto-generated constructor stub
        mMsg = msg;
    }
    public String getMsg(){
        return mMsg;
    }
}
