package com.joy.property.neighborhood;

/**
 * Created by xz on 2016/4/6.
 */
public class RefreshEvent {
    private String mMsg;
    public RefreshEvent(String msg) {
        // TODO Auto-generated constructor stub
        mMsg = msg;
    }
    public String getMsg(){
        return mMsg;
    }
}
