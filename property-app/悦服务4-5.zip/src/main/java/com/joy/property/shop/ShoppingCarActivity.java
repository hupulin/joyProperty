package com.joy.property.shop;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.jinyi.ihome.infrastructure.MessageToBulk;
import com.jinyi.ihome.module.newshop.AddCarParam;
import com.jinyi.ihome.module.newshop.CarGoodsInfo;
import com.jinyi.ihome.module.newshop.CartSettleGoodsTo;
import com.jinyi.ihome.module.newshop.ChangeCarParam;
import com.jinyi.ihome.module.newshop.CouponParam;
import com.jinyi.ihome.module.newshop.CouponTo;
import com.jinyi.ihome.module.newshop.DeleteGoodsParam;
import com.jinyi.ihome.module.newshop.MakeOrderParam;
import com.jinyi.ihome.module.newshop.MyShopCarTo;
import com.jinyi.ihome.module.newshop.SaveCouponParam;
import com.joy.common.api.ApiClientBulk;
import com.joy.common.api.HttpCallback;
import com.joy.common.api.NewShopApi;

import com.joy.property.R;

import com.joy.property.base.BaseActivity;
import com.joyhome.nacity.app.photo.util.PublicWay;
import com.joy.property.shop.adapter.CouponAdapter;
import com.joy.property.shop.adapter.ShoppingCarAdapter;
import com.joy.property.shop.shoputil.DoubleUtil;
import com.joyhome.nacity.app.util.CustomDialog;
import com.joyhome.nacity.app.util.CustomDialogFragment;
import com.joyhome.nacity.app.util.SpUtil;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit.RetrofitError;
import retrofit.client.Response;
import rx.Observable;

/**
 * Created by xz on 2016/7/21.
 **/
public class ShoppingCarActivity extends BaseActivity implements View.OnClickListener {
    private ImageView goodsSelect;
    private ImageView allSelect;
    private TextView priceLeft;
    private TextView priceRight;
    private TextView containTraffic;
    private TextView balance;
    private SwipeMenuListView listView;
    private List<MyShopCarTo> carList=new ArrayList<>();
    private ShoppingCarAdapter adapter;
    private Boolean isAllSelect=false;

    private   double allPrice=0.00;

    private double trafficFee=0;

    private GridLayout gridView;
    private List<CarGoodsInfo> goodsInfoList = new ArrayList<>();;
    private List<CarGoodsInfo> lastDetailList=new ArrayList<>();
    private String cartId;
    private List<DeleteGoodsParam.CartGoodsListBean>cartGoodsListBeans=new ArrayList<>();
    private List<ChangeCarParam.ChangeCartGoods>cartGoodsList=new ArrayList<>();
    private List<CarGoodsInfo> carGoodsList=new ArrayList<>();
    private List<CouponTo>couponSaveList=new ArrayList<>();
    private List<CouponTo>couponList=new ArrayList<>();
    private RelativeLayout bulkLayout;
    private ImageView noshop;
    private int allCount;
    private int allCountSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_car);
        initView();
        initData();
        setAdapterListener();
        PublicWay.activityList.add(this);
    }
    private void initView() {
        findViewById(R.id.back).setOnClickListener(this);
        goodsSelect = (ImageView) findViewById(R.id.goodsSelect);
        findViewById(R.id.coupons).setOnClickListener(this);
        allSelect = (ImageView) findViewById(R.id.allSelect);
        priceLeft = (TextView) findViewById(R.id.priceLeft);
        priceRight = (TextView) findViewById(R.id.priceRight);
        containTraffic = (TextView) findViewById(R.id.containTraffic);
        balance = (TextView) findViewById(R.id.balance);
        gridView = (GridLayout) findViewById(R.id.gridView);
        listView = (SwipeMenuListView) findViewById(R.id.listView);
        listView.setDividerHeight(0);
        adapter=new ShoppingCarAdapter(getThisContext(),this);
        goodsSelect.setOnClickListener(this);
        allSelect.setOnClickListener(this);
        findViewById(R.id.coupons).setOnClickListener(this);
        findViewById(R.id.balanceLayout).setOnClickListener(this);
        bulkLayout = (RelativeLayout) findViewById(R.id.bulkLayout);
        noshop = (ImageView) findViewById(R.id.noShop);
        findViewById(R.id.allSelectText).setOnClickListener(this);
    }
    private void initData() {
        SpUtil.put(getThisContext(), "HaveAddCar", false);
        NewShopApi api= ApiClientBulk.create(NewShopApi.class);
        final CustomDialogFragment dialogFragment = new CustomDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), "");
        AddCarParam param=new AddCarParam();
        param.setUserId(mUserHelperBulk.getSid());
        api.getMyShopCar(param, new HttpCallback<MessageToBulk<List<MyShopCarTo>>>(ShoppingCarActivity.this) {
            @Override
            public void success(MessageToBulk<List<MyShopCarTo>> msg, Response response) {
                dialogFragment.dismiss();
                carList.clear();
                if (msg.getCode() == 0) {

                    if (msg.getCartMerchantGoodsGlobalVoList() != null && msg.getCartMerchantGoodsGlobalVoList().size() > 0) {
                        cartId = msg.getCartMerchantGoodsGlobalVoList().get(0).getCartId();
                        carList.addAll(msg.getCartMerchantGoodsGlobalVoList());
                        setView(carList);
                    } else {
                        bulkLayout.setVisibility(View.GONE);
                        noshop.setVisibility(View.VISIBLE);
                    }
                   setPrice(goodsInfoList);
                 listView.setOnItemClickListener((adapterView, view, position, l) -> {
                     if (!TextUtils.isEmpty(goodsInfoList.get(position).getGoodsId())) {
                         if ("正常".equals(goodsInfoList.get(position).getIsInvalid())) {
                             Intent intent = new Intent(getThisContext(), GoodsDetailActivity.class);
                             intent.putExtra("GoodsSid", goodsInfoList.get(position).getGoodsId());
                             startActivity(intent);
                         } else {
                             startActivity(new Intent(getThisContext(), InvalidGoodsActivity.class));
                         }
                      goToAnimation(1);
                   }else {
                         jumpShop(goodsInfoList.get(position).getMerchantId(), goodsInfoList.get(position).getSalesType(), goodsInfoList.get(position).getStoresNameTop());

                     }  });

                } else
                    ToastShowLong(getThisContext(), msg.getMessage());
            }

            @Override
            public void failure(RetrofitError error) {
                super.failure(error);
                dialogFragment.dismiss();
            }
        });
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back:
                onBackPressed();
                break;
            case R.id.allSelect:
            case R.id.allSelectText:
                allSelect();
                break;
            case R.id.balanceLayout:
                if (!check()) {
                    ToastShowLong(getThisContext(), "请至少选择一件商品");
                    return;
                }
            makeOrder();
                break;
        }
    }
    public void initSwipeMenu(SwipeMenuListView listView){
        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "open" item


                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9,
                        0x3F, 0x25)));
                // set item width
                deleteItem.setWidth(dp2px(90));
                // set a icon
                deleteItem.setIcon(R.drawable.ic_delete);
                // add to menu
                menu.addMenuItem(deleteItem);
            }
        };
        // set creator
        listView.setMenuCreator(creator);

        // step 2. listener item click event
        listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                CarGoodsInfo item = goodsInfoList.get(position);
                System.out.println(goodsInfoList.toString());
                switch (index) {
                    case 0:

                        cartGoodsListBeans.clear();
                        if (item.getMerchantNameTop() != null || item.getStoresNameTop() != null) {
                            Observable.from(carList).filter(myShopCarTo -> item.getMerchantId().equals(myShopCarTo.getMerchantId())).subscribe(myShopCarTo -> {
                                if (myShopCarTo.getCartMerchantGoodsVolist() != null)
                                    for (CarGoodsInfo goodsDetail : myShopCarTo.getCartMerchantGoodsVolist()) {
                                        DeleteGoodsParam.CartGoodsListBean bean = new DeleteGoodsParam.CartGoodsListBean();
                                        bean.setGoodsId(goodsDetail.getGoodsId());
                                        if (bean.getGoodsId() != null)
                                            cartGoodsListBeans.add(bean);
                                    }
                            });
                        } else {
                            DeleteGoodsParam.CartGoodsListBean goodBean = new DeleteGoodsParam.CartGoodsListBean();
                            goodBean.setGoodsId(item.getGoodsId());
                            cartGoodsListBeans.add(goodBean);
                        }

                        if (cartGoodsListBeans != null && cartGoodsListBeans.size() > 0)
                            deleteGoods(cartGoodsListBeans, position);

                        break;

                }
                return false;
            }
        });
    }
    private int dp2px(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                getResources().getDisplayMetrics());
    }


    public void allSelect(){
if (isAllSelect){
    isAllSelect=false;
    allSelect.setBackgroundResource(R.drawable.shopping_car_circle);
    for (int i = 0; i < goodsInfoList.size(); i++) {
        if ("正常".equals(goodsInfoList.get(i).getIsInvalid()))
            goodsInfoList.get(i).setIsSelect(false);
            goodsInfoList.get(i).setIsShopSelect(false);
    }
}else {
    isAllSelect=true;
    allSelect.setBackgroundResource(R.drawable.shopping_car_select);
    for (int i = 0; i < goodsInfoList.size(); i++){
        if ( "正常".equals(goodsInfoList.get(i).getIsInvalid()))
            goodsInfoList.get(i).setIsSelect(true);
            goodsInfoList.get(i).setIsShopSelect(true);
        }
}
        setPrice(goodsInfoList);
        adapter.notifyDataSetChanged();
    }

    private void ConponDialogShow(CarGoodsInfo mode) {

        final CustomDialog dialog = new CustomDialog(this, R.layout.dialog_coupon, R.style.myDialogTheme);
        NewShopApi api= ApiClientBulk.create(NewShopApi.class);
        CouponParam param=new CouponParam();
        ImageView noCoupon = (ImageView) dialog.findViewById(R.id.noCoupon);
        TextView storeName = (TextView) dialog.findViewById(R.id.storeName);
        storeName.setText(mode.getStoresNameTop());
        param.setCartId(mode.getCartIdTop());
        param.setMerchantId(mode.getMerchantId());
        param.setUserId(mUserHelperBulk.getSid());

        List<CouponParam.CouponParamTo> couponParamToList=new ArrayList<>();

        couponParamToList.clear();
        for (CarGoodsInfo goodsInfo:goodsInfoList){
            CouponParam.CouponParamTo couponParamTo=new CouponParam.CouponParamTo();
            if (goodsInfo.getGoodsId()!=null&&goodsInfo.getMerchantId().equals(mode.getMerchantId())){
                couponParamTo.setGoodsId(goodsInfo.getGoodsId());
                couponParamTo.setCurrentPrice(goodsInfo.getCurrentPrice() + "");
                couponParamTo.setGoodsNum(goodsInfo.getGoodsNum()+"");
                couponParamToList.add(couponParamTo);
            }
        }

     param.setMerchantGoodslist(couponParamToList);

        api.getCoupon(param, new HttpCallback<MessageToBulk<List<CouponTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<CouponTo>> msg, Response response) {
                if (msg.getCode() == 0) {
                    if (msg.getCartCouponList() != null) {
                        couponList.clear();
                        couponList.addAll(msg.getCartCouponList());
                        if (couponList.size()>0)
                            noCoupon.setVisibility(View.GONE);
                        CouponAdapter couponAdapter = new CouponAdapter(getThisContext());
                        couponAdapter.setList(couponList);


                        ListView listView = (ListView) dialog.findViewById(R.id.listView);
                        listView.setAdapter(couponAdapter);
                        listView.setDividerHeight(0);
                        couponAdapter.notifyDataSetChanged();
                        couponAdapter.setSaveCoupon((couponSid, position) -> confirmCoupon(mode.getMerchantId(), couponSid, dialog,position));
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                super.failure(error);

            }
        });

        RelativeLayout layout = (RelativeLayout) dialog.findViewById(R.id.layout);
        layout.setOnClickListener(v -> dialog.dismiss());
  //getCouponList(couponAdapter,couponList);
        TextView purchaseClose = (TextView) dialog.findViewById(R.id.cancel);
        purchaseClose.setOnClickListener(v -> dialog.dismiss());

        dialog.setCanceledOnTouchOutside(true);
        dialog.setCancelable(true);
        dialog.show();


    }

    public void setView(List<MyShopCarTo> shopCarToList){

        lastDetailList.clear();
        lastDetailList.addAll(goodsInfoList);
        goodsInfoList.clear();
        for (int i=0;i<shopCarToList.size();i++) {

            CarGoodsInfo myTitleCar=new CarGoodsInfo();

            MyShopCarTo myShopCar=shopCarToList.get(i);
            myTitleCar.setMerchantNameTop(myShopCar.getMerchantName());
            myTitleCar.setStoresNameTop(myShopCar.getStoresName());
            myTitleCar.setMerchantId(myShopCar.getMerchantId());
            myTitleCar.setCartIdTop(myShopCar.getCartId());
            myTitleCar.setSalesType( myShopCar.getCartMerchantGoodsVolist().get(0).getSalesType());
            myTitleCar.setIsInvalid("正常");

            goodsInfoList.add(myTitleCar);
            myShopCar.getCartMerchantGoodsVolist().get(myShopCar.getCartMerchantGoodsVolist().size()-1).setNoLine(true);
            goodsInfoList.addAll(myShopCar.getCartMerchantGoodsVolist());

        }

        if (lastDetailList.size()>0){
            for (int i=0;i< goodsInfoList.size(); i++)
                for (CarGoodsInfo detail:lastDetailList){
if (goodsInfoList.get(i).getGoodsId()!=null) {
    if (goodsInfoList.get(i).getGoodsId().equals(detail.getGoodsId())) {
        goodsInfoList.get(i).setIsSelect(detail.isSelect());

    }
}else {
    if (goodsInfoList.get(i).getMerchantId()!=null&&goodsInfoList.get(i).getMerchantId().equals(detail.getMerchantId())) {

        goodsInfoList.get(i).setIsShopSelect(detail.isShopSelect());
    }
}
                }
        }
        adapter.setList(goodsInfoList);
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        initSwipeMenu(listView);
    }
    public void deleteGoods(List<DeleteGoodsParam.CartGoodsListBean> cartGoodsListBeans,int position){
        NewShopApi api= ApiClientBulk.create(NewShopApi.class);
        DeleteGoodsParam param=new DeleteGoodsParam();
        param.setCartGoodsList(cartGoodsListBeans);
        param.setCartId(cartId);
        System.out.println(param + "param");
        CustomDialogFragment dialogFragment=new CustomDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), "");
        api.deleteGoods(param, new HttpCallback<MessageToBulk>(getThisContext()) {
            @Override
            public void success(MessageToBulk msg, Response response) {

                dialogFragment.dismiss();
                if (msg.getCode() == 0) {
                    goodsInfoList.remove(position);
                    initData();

                }
            }
        });
    }
    private void setAdapterListener() {

        adapter.setPurchaseNumberChangeListener((select, position, goodsTo) -> {
            if (select)
                goodsInfoList.get(position).setIsSelect(true);
            else {
                goodsInfoList.get(position).setIsSelect(false);
                for (int i = 0; i < goodsInfoList.size(); i++) {
                    if (goodsTo.getMerchantId().equals(goodsInfoList.get(i).getMerchantId())) {
                        goodsInfoList.get(i).setIsShopSelect(false);
                    }

                }
            }

            setPrice(goodsInfoList);
        });
        adapter.setChangeGoodsListener((goodsId, number, position, isAdd, mode) -> {
            cartGoodsList.clear();
            ChangeCarParam.ChangeCartGoods cartGoods = new ChangeCarParam.ChangeCartGoods();
            cartGoods.setGoodsId(goodsId);
            cartGoods.setPurchaseQuantity(number);
            cartGoodsList.add(cartGoods);
            changeGoods(cartGoodsList, position, isAdd, mode);
        });
        adapter.setShopAllSelect((select, merchantId) -> {
            if (select) {
                for (int i = 0; i < goodsInfoList.size(); i++) {
                    if (merchantId.equals(goodsInfoList.get(i).getMerchantId()) && "正常".equals(goodsInfoList.get(i).getIsInvalid())) {
                        goodsInfoList.get(i).setIsSelect(true);
                        goodsInfoList.get(i).setIsShopSelect(true);
                    }
                }
            } else {
                for (int i = 0; i < goodsInfoList.size(); i++)
                    if (merchantId.equals(goodsInfoList.get(i).getMerchantId()) && "正常".equals(goodsInfoList.get(i).getIsInvalid())) {
                        goodsInfoList.get(i).setIsSelect(false);
                        goodsInfoList.get(i).setIsShopSelect(false);
                    }

            }
            setPrice(goodsInfoList);
            adapter.notifyDataSetChanged();
        });
        adapter.setGetCoupon(mode -> ConponDialogShow(mode));
    }
    public void changeGoods(List<ChangeCarParam.ChangeCartGoods> cartGoodsList,int position,boolean isAdd,CarGoodsInfo mode){
        NewShopApi api= ApiClientBulk.create(NewShopApi.class);
        ChangeCarParam param=new ChangeCarParam();
        param.setCartId(cartId);
        param.setCartGoodsList(cartGoodsList);
        api.changeShopCar(param, new HttpCallback<MessageToBulk>(getThisContext()) {
            @Override
            public void success(MessageToBulk msg, Response response) {
                if (msg.getCode() == 0) {
                    if (isAdd)
                        mode.setGoodsNum(mode.getGoodsNum() + 1);
                    else
                        mode.setGoodsNum(mode.getGoodsNum() - 1);
                    setPrice(goodsInfoList);
                }

            }
        });

    }
    public void setPrice(List<CarGoodsInfo> carGoodsListTo){
        allCount=0;
        allCountSelect=0;
        allPrice=0.00;
        trafficFee=0;
        double maxTrafficFee=0;
        for (CarGoodsInfo goodsDetail:carGoodsListTo){
            if (goodsDetail.isSelect()){
                allPrice= DoubleUtil.add(allPrice,goodsDetail.getCurrentPrice()*goodsDetail.getGoodsNum());
              //  allPrice=allPrice+goodsDetail.getCurrentPrice()*goodsDetail.getGoodsNum();
            }
            if (goodsDetail.getDistributionCost()>=maxTrafficFee)
                maxTrafficFee=goodsDetail.getDistributionCost();
        }
        priceLeft.setText((int)allPrice+"");
        String  moneyRight=allPrice-(int)allPrice+"0";
       priceRight.setText(moneyRight.substring(moneyRight.indexOf("."), moneyRight.length()));

        //运费计算
        for (MyShopCarTo shopCarTo: carList){
            maxTrafficFee=0;
            for (CarGoodsInfo goodsDetail:carGoodsListTo){
                if (shopCarTo.getMerchantId().equals(goodsDetail.getMerchantId())){
                    if (goodsDetail.isSelect()&&goodsDetail.getDistributionCost()>=maxTrafficFee)
                    {
                        maxTrafficFee=goodsDetail.getDistributionCost();

                    }
                }
            }
            trafficFee=DoubleUtil.add(trafficFee,maxTrafficFee);
        }
        containTraffic.setText(trafficFee > 0 ? "配送费:¥" + trafficFee + "" : "不含运费");
        Observable.from(goodsInfoList).filter(CarGoodsInfo::isSelect).filter(carGoodsInfo1 -> carGoodsInfo1.getGoodsId() != null).subscribe(carGoodsInfo -> {
            allCount++;
        });
        Observable.from(goodsInfoList).filter(CarGoodsInfo::isSelect).subscribe(carGoodsInfo -> {
            allCountSelect++;
        });
        if (allCountSelect<goodsInfoList.size())
            allSelect.setBackgroundResource(R.drawable.shopping_car_circle);
        else
            allSelect.setBackgroundResource(R.drawable.shopping_car_select);
        balance.setText(allCount + "");
        adapter.notifyDataSetChanged();

    }
public void confirmCoupon(String merchantId,String couponId,CustomDialog dialog,int position){
NewShopApi api= ApiClientBulk.create(NewShopApi.class);
    SaveCouponParam param=new SaveCouponParam();
    param.setMerchantId(merchantId);
    param.setCartId(cartId);
    param.setCouponId(couponId);
    api.confirmCoupon(param, new HttpCallback<MessageToBulk>(getThisContext()) {
        @Override
        public void success(MessageToBulk msg, Response response) {
            if (msg.getCode() == 0) {
                if (!couponSaveList.contains(couponList.get(position)))
                    couponSaveList.add(couponList.get(position));
                dialog.dismiss();
            }
        }
    });
}
    //结算
    public void makeOrder(){
        NewShopApi api= ApiClientBulk.create(NewShopApi.class);
        MakeOrderParam param=new MakeOrderParam();
         param.setCartId(cartId);
        List<MakeOrderParam.MerchantList> merchantList=new ArrayList<>();
        merchantList.clear();
        for(int i=0;i<carList.size();i++){
        carList.get(i).setHaveSelect(false);
         for (CarGoodsInfo goodsInfo : goodsInfoList){
        if (carList.get(i).getMerchantId().equals(goodsInfo.getMerchantId())&&goodsInfo.getGoodsId()!=null&&goodsInfo.isSelect()){
            carList.get(i).setHaveSelect(true);

            break;
        }
    }
}
        for (MyShopCarTo shopCarTo:carList ) {
if (shopCarTo.isHaveSelect()) {
    List<MakeOrderParam.MerchantList.MerchantGoodslist>merchantGoodslists=new ArrayList<>();
    merchantGoodslists.clear();
    MakeOrderParam.MerchantList merchant = new MakeOrderParam.MerchantList();
    merchant.setMerchantId(shopCarTo.getMerchantId());
    for (CarGoodsInfo goodsInfo : goodsInfoList) {


        if (shopCarTo.getMerchantId().equals(goodsInfo.getMerchantId()) && !TextUtils.isEmpty(goodsInfo.getGoodsId()) && goodsInfo.isSelect()) {

            MakeOrderParam.MerchantList.MerchantGoodslist merchantGoodslist = new MakeOrderParam.MerchantList.MerchantGoodslist();
            merchantGoodslist.setGoodsId(goodsInfo.getGoodsId());
            merchantGoodslist.setGoodsNum(goodsInfo.getGoodsNum() + "");
            merchantGoodslists.add(merchantGoodslist);
        }

    }
    merchant.setMerchantGoodslist(merchantGoodslists);
    merchantList.add(merchant);
}

        }
        param.setMerchantList(merchantList);
        CustomDialogFragment dialogFragment=new CustomDialogFragment();
        dialogFragment.show(getSupportFragmentManager(), "");

        api.makeOrder(param, new HttpCallback<MessageToBulk<List<CartSettleGoodsTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<CartSettleGoodsTo>> msg, Response response) {
                dialogFragment.dismiss();
                if (msg.getCode() == 0) {

                    Intent intent = new Intent(getThisContext(), ConfirmOlderActivity.class);
                    List<CartSettleGoodsTo> settleGoodsToList = new ArrayList<>();
                    if (msg.getCartSettleGoodsVoList() != null) {
                        settleGoodsToList.addAll(msg.getCartSettleGoodsVoList());
                    }
                    intent.putExtra("carList", (Serializable) (settleGoodsToList));
                    intent.putExtra("IsSeaBuy",msg.getIsSeaBuy());
                    startActivity(intent);
                    goToAnimation(1);
                } else

                    ToastShowLong(getThisContext(), msg.getMessage());
            }

            @Override
            public void failure(RetrofitError error) {
                dialogFragment.dismiss();
            }
        });
    }
    public boolean check(){
        boolean haveSelect=false;
        for (CarGoodsInfo goodsInfo:goodsInfoList){
            if (goodsInfo.isSelect()&&goodsInfo.getGoodsId()!=null) {
                haveSelect = true;
                break;
            }

        }
        return haveSelect;
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        goToAnimation(2);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode==KeyEvent.KEYCODE_BACK)
            onBackPressed();
        return super.onKeyDown(keyCode, event);
    }
    public void jumpShop(String shopSid,String name,String storeName){
        Intent intent;
        if ("自营商品".equals(name))
            intent=new Intent(getThisContext(),SelfShopActivity.class);
        else
            intent=new Intent(getThisContext(),MerchantShopActivity.class);
        intent.putExtra("ShopSid",shopSid);
        intent.putExtra("ShopName",storeName);
        startActivity(intent);
        goToAnimation(1);
    }

    @Override
    protected void onRestart() {
     
        if (SpUtil.getBoolean(getThisContext(), "HaveAddCar")){
            initData();

        }
        super.onRestart();

    }
}
