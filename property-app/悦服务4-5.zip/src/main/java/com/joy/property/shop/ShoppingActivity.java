package com.joy.property.shop;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import com.ToxicBakery.viewpager.transforms.ABaseTransformer;
import com.ToxicBakery.viewpager.transforms.ForegroundToBackgroundTransformer;
import com.bigkoo.convenientbanner.ConvenientBanner;
import com.bigkoo.convenientbanner.listener.OnItemClickListener;
import com.jinyi.ihome.infrastructure.MessageTo;
import com.jinyi.ihome.infrastructure.MessageToBulk;
import com.jinyi.ihome.module.newshop.AddCarParam;
import com.jinyi.ihome.module.newshop.BlankParam;
import com.jinyi.ihome.module.newshop.BulkUserInfoParam;
import com.jinyi.ihome.module.newshop.CategoryChannelTo;
import com.jinyi.ihome.module.newshop.CategoryTo;
import com.jinyi.ihome.module.newshop.ChannelParam;
import com.jinyi.ihome.module.newshop.MainInfoDettailTo;
import com.jinyi.ihome.module.newshop.MainInfoTo;
import com.jinyi.ihome.module.newshop.MyShopCarTo;
import com.jinyi.ihome.module.newshop.UserMessage;
import com.jinyi.ihome.module.owner.UserInfoTo;
import com.joy.common.api.ApiClientBulk;
import com.joy.common.api.HttpCallback;
import com.joy.common.api.NewShopApi;
import com.joy.property.R;
import com.joy.property.base.BaseActivity;
import com.joyhome.nacity.app.MainApp;

import com.joyhome.nacity.app.photo.util.PublicWay;
import com.joyhome.nacity.app.propertyCenter.NetworkImageHolderView;
import com.joy.property.shop.adapter.HotAdapter;
import com.joy.property.shop.shoputil.CarNumberUtil;
import com.joyhome.nacity.app.util.CustomDialogFragment;
import com.joyhome.nacity.app.util.ViewPagerCompat;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import retrofit.RetrofitError;
import retrofit.client.Response;
import rx.Observable;

/**
 * Created by xz on 2016/7/13.
 **/
public class ShoppingActivity extends BaseActivity implements OnItemClickListener, View.OnClickListener {
    private List<MainInfoDettailTo> list = new ArrayList<>();
    private ConvenientBanner autoRow;
    private List<CategoryChannelTo> shopList = new ArrayList<>();
    private ImageView selling;
    private ImageView sellingOne;
    private ImageView sellingThree;
    private ImageView searchGoods;
    private ListView listView;
    private ScrollView scrollView;
    private List<CategoryTo> categoryList = new ArrayList<>();
    private HotAdapter adapter;
    private TextView carNumber;
    private LinearLayout menuLayout;
    private List<MainInfoDettailTo> shopAdList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping);

        initView();
        setAutoRow();
        getChannel();
        getChannelList();
        getType();
        getUserInfo();
        setJumpActivity();
        getAdPosition();
        addMenu();
        PublicWay.activityList.add(this);

    }


    private void initView() {
        autoRow = (ConvenientBanner) findViewById(R.id.autoRow);
        selling = (ImageView) findViewById(R.id.sellingLayout);
        sellingOne = (ImageView) findViewById(R.id.selling_right_one);
        sellingThree = (ImageView) findViewById(R.id.selling_right_three);
        selling.setOnClickListener(this);
        sellingOne.setOnClickListener(this);
        sellingThree.setOnClickListener(this);
        listView = (ListView) findViewById(R.id.listView);
        setListViewHeightBasedOnChildren(listView);
        listView.setDividerHeight(0);
        scrollView = (ScrollView) findViewById(R.id.scrollView);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
        findViewById(R.id.shop_type).setOnClickListener(this);
        LinearLayout unListView = (LinearLayout) findViewById(R.id.un_listView);
        unListView.setFocusable(true);
        unListView.setFocusableInTouchMode(true);
        listView.requestFocus();
        findViewById(R.id.shoppingCar).setOnClickListener(this);
        findViewById(R.id.lookAllGoods).setOnClickListener(this);
        carNumber = (TextView) findViewById(R.id.carNumber);
        menuLayout = (LinearLayout) findViewById(R.id.menuLayout);
        findViewById(R.id.back).setOnClickListener(this);
        searchGoods= (ImageView)findViewById(R.id.searchGoods);
        searchGoods.setOnClickListener(this);
       // findViewById(R.id.searchGoods).setOnClickListener(this);
    }
    private void setAutoRow() {
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        Log.i("999", mUserHelperBulk.getUserInfoTo().toString());
        api.getMainPageInfo("1", mUserHelperBulk.getUserInfoTo().getApartmentSid(), new HttpCallback<MessageTo<MainInfoTo>>(this) {
            @Override
            public void success(MessageTo<MainInfoTo> msg, Response response) {
                if (msg.getSuccess() == 0) {
                    if (msg.getData() != null && msg.getData().getList() != null && msg.getData().getList().size() > 0) {
                        list.clear();
                        list.addAll(msg.getData().getList());
                        getAdInfoSecond(msg.getData().getList());
                    }else {
                        autoRow.setVisibility(View.GONE);
                        searchGoods.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                autoRow.setVisibility(View.GONE);
                searchGoods.setVisibility(View.GONE);
                System.out.println(error + "error");
            }
        });
    }

    private void getAdInfoSecond(List<MainInfoDettailTo> mList) {
        String transforemerName = ForegroundToBackgroundTransformer.class.getSimpleName();
        try {
            Class cls = Class.forName("com.ToxicBakery.viewpager.transforms." + transforemerName);
            ABaseTransformer transforemer = (ABaseTransformer) cls.newInstance();
            autoRow.getViewPager().setPageTransformer(true, transforemer);
            if (transforemerName.equals("StackTransformer")) {
                autoRow.setScrollDuration(1200);
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        //  initImageLoader();

        List<String> networkImages = new ArrayList<>();
        for (int i = 0; i < mList.size(); i++)
            networkImages.add(MainApp.getPicassoImagePath(mList.get(i).getPicUrl()));
        autoRow.setPages(NetworkImageHolderView::new, networkImages).setPageIndicator(new int[]{R.drawable.ic_page_indicator, R.drawable.ic_page_indicator_focused}).setPageIndicatorAlign(ConvenientBanner.PageIndicatorAlign.ALIGN_PARENT_RIGHT).setOnItemClickListener(position -> {
            adJump(mList.get(position));
        });
        autoRow.startTurning(5000);

    }

    @Override
    public void onItemClick(int position) {

    }

    private void getChannel() {

//                    channelList.clear();
//              for(int i=0;i<3;i++){
//                  ShopTypeTo typeTo=new ShopTypeTo();
//                  typeTo.setTypeName("频道"+i);
//                  typeTo.setTypeSid("3333");
//                  typeTo.setTypeIcon(MainApp.getPicassoImagePath("shop_head_image.jpg"));
//                  channelList.add(typeTo);
//              }
//                    Picasso.with(getThisContext()).load(channelList.get(0).getTypeIcon()).into(selling);
//                    Picasso.with(getThisContext()).load(channelList.get(1).getTypeIcon()).into(sellingOne);
//                    Picasso.with(getThisContext()).load(channelList.get(2).getTypeIcon()).into(sellingThree);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.back:
                onBackPressed();
                break;
            case R.id.sellingLayout:
                Observable.from(shopAdList).filter(mainInfoDettailTo -> mainInfoDettailTo.getAdPosition() == 1).subscribe(this::adJump);

                break;
            case R.id.searchGoods:
                Intent intentSearch = new Intent(getThisContext(), SearchActivity.class);
                startActivity(intentSearch);
                goToAnimation(1);
                break;
            case R.id.selling_right_one:
                Observable.from(shopAdList).filter(mainInfoDettailTo -> mainInfoDettailTo.getAdPosition() == 2).subscribe(this::adJump);
                break;
//            case R.id.selling_right_tow:
//
//                break;
            case R.id.selling_right_three:
                Observable.from(shopAdList).filter(mainInfoDettailTo -> mainInfoDettailTo.getAdPosition() == 3).subscribe(this::adJump);
                break;
//            case R.id.selling_right_four:
//
//                break;
            case R.id.shop_type:
                showType();
                break;
            case R.id.shoppingCar:
                startActivity(new Intent(getThisContext(), ShoppingCarActivity.class));
                goToAnimation(1);

                break;
            case R.id.lookAllGoods:
                Intent intent = new Intent(getThisContext(), ActivityShopMore.class);
                startActivity(intent);

                goToAnimation(1);
                break;
            case R.id.propertyBulk:
                Intent intent2 = new Intent(getThisContext(), ShopBulkActivity.class);
                startActivity(intent2);
                goToAnimation(1);
                break;


        }
    }

    public void getChannelList() {
        adapter = new HotAdapter(getThisContext());
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        ChannelParam param = new ChannelParam();
        param.setCommunityId(mUserHelperBulk.getUserInfoTo().getApartmentSid());
        api.getChannelGoodsList(param, new HttpCallback<MessageToBulk<List<CategoryChannelTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<CategoryChannelTo>> msg, Response response) {
                if (msg.getCode() == 0) {
                    shopList.clear();
                    if (msg.getCommunityCategoryGoodsVoList() != null)
                        shopList.addAll(msg.getCommunityCategoryGoodsVoList());
                    //  setShopList();
                    adapter.setList(shopList);
                    listView.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                    findViewById(R.id.lookAllGoods).setVisibility(View.VISIBLE);
                    listView.setOnItemClickListener((adapterView, view, position, l) -> {
                        Intent intent = new Intent(getThisContext(), ShopMoreType.class);
                        CategoryTo categoryTo = new CategoryTo();
                        categoryTo.setName(shopList.get(position).getCategoryName());
                        categoryTo.setId(shopList.get(position).getCategoryId());
                        intent.putExtra("category", categoryTo);
                        startActivity(intent);
                        goToAnimation(1);
                    });

                    scrollView.post(() -> scrollView.scrollTo(0, 0));
                    setListViewHeightBasedOnChildren(listView);

                } else
                    ToastShowLong(getThisContext(), msg.getMessage());

            }

            @Override
            public void failure(RetrofitError error) {

            }
        });
    }


    public static void setListViewHeightBasedOnChildren(ListView listView) {
        if (listView == null) return;
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            // pre-condition
            return;
        }
        int totalHeight = 0;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            View listItem = listAdapter.getView(i, null, listView);
            listItem.measure(0, 0);
            totalHeight += listItem.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
    }

    public void showType() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View contentView = inflater.inflate(R.layout.dialog_shop_type, null);

        GridLayout channelGorup = (GridLayout) contentView.findViewById(R.id.channel_group);
        for (CategoryTo shopListTo : categoryList) {
            View linearLayout = LinearLayout.inflate(getThisContext(), R.layout.shop_type_pup_item, null);
            TextView channelName = (TextView) linearLayout.findViewById(R.id.channel_name);
            channelName.setText(shopListTo.getName());
            linearLayout.setOnClickListener(v -> ToastShowLong(getThisContext(), shopListTo.getName()));
            WindowManager wm = (WindowManager) getThisContext().getSystemService(getThisContext().WINDOW_SERVICE);
            Display display = wm.getDefaultDisplay();
            int mWidth = display.getWidth();
            int marginLeft = (int) (mWidth * 0.0805);
            int marginBottom = (int) (mWidth * 0.0486);
            int width = (int) (mWidth * 0.2013);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = width;
            lp.height = (int) (mWidth * 0.0416);
            lp.setMargins(marginLeft, 0, 0, marginBottom);
            linearLayout.setLayoutParams(lp);
            linearLayout.setOnClickListener(v -> {
                Intent intent = new Intent(getThisContext(), ShopMoreType.class);
                intent.putExtra("category", shopListTo);

                startActivity(intent);
                goToAnimation(1);
            });
            channelGorup.addView(linearLayout);
        }

        View view = findViewById(R.id.layout_title);
        contentView.setFocusable(true);
        contentView.setFocusableInTouchMode(true);

        PopupWindow popupWindow = new PopupWindow(contentView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());
        popupWindow.setFocusable(true);
        contentView.findViewById(R.id.pup_layout).setOnClickListener(v -> popupWindow.dismiss());
        popupWindow.setOutsideTouchable(true);
        popupWindow.showAsDropDown(view);
    }

    private void getType() {
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        BlankParam param = new BlankParam();
        param.setCommunityId(mUserHelperBulk.getUserInfoTo().getApartmentSid());
        api.getCategory(param, new HttpCallback<MessageToBulk<List<CategoryTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<CategoryTo>> msg, Response response) {
                if (msg.getCode() == 0) {
                    categoryList.clear();
                    if (msg.getGoodsCategoryList() != null)
                        categoryList.addAll(msg.getGoodsCategoryList());

                }
            }

            @Override
            public void failure(RetrofitError error) {

            }
        });
    }

    public void getUserInfo() {
        if (mUserHelperBulk.getUserInfoTo() != null) {
            getMyShopCar();

        }

    }

    public void getMyShopCar() {
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        AddCarParam param = new AddCarParam();
        param.setUserId(mUserHelperBulk.getSid());
        api.getMyShopCar(param, new HttpCallback<MessageToBulk<List<MyShopCarTo>>>(getThisContext()) {
            @Override
            public void success(MessageToBulk<List<MyShopCarTo>> msg, Response response) {
                if (msg.getCode() == 0) {
                    int count = 0;
                    if (msg.getCartMerchantGoodsGlobalVoList() != null) {
                        for (MyShopCarTo myShopCarTo : msg.getCartMerchantGoodsGlobalVoList()) {
                            if (myShopCarTo != null && myShopCarTo.getCartMerchantGoodsVolist() != null) {
                                count = count + myShopCarTo.getCartMerchantGoodsVolist().size();
                            }
                        }
                    }
                    carNumber.setText(count + "");
                }
            }
        });
    }

    private void setJumpActivity() {
        adapter.setJumpAcitivty(goodsSid -> {
            Intent intent = new Intent(getThisContext(), GoodsDetailActivity.class);
            intent.putExtra("GoodsSid", goodsSid);
            startActivity(intent);

            goToAnimation(1);
        });
    }

    public void getAdPosition() {
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        api.getMainPageInfo("3", mUserHelperBulk.getUserInfoTo().getApartmentSid(), new HttpCallback<MessageTo<MainInfoTo>>(this) {
            @Override
            public void success(MessageTo<MainInfoTo> msg, Response response) {
                if (msg.getSuccess() == 0) {

                    if (msg.getData() != null && msg.getData().getList() != null && msg.getData().getList().size() > 0) {
                        setAdPosition(msg.getData().getList());
                        shopAdList.addAll(msg.getData().getList());
                        System.out.println(shopAdList+"adList");
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
            }
        });
    }

    public void setAdPosition(List<MainInfoDettailTo> adList) {
        Observable.from(adList).filter(mainInfoDettailTo -> mainInfoDettailTo.getAdPosition() == 1).subscribe(mainInfoDettailTo1 -> Picasso.with(getThisContext()).load(MainApp.getPicassoImagePath(mainInfoDettailTo1.getPicUrl())).into(selling));
        Observable.from(adList).filter(mainInfoDettailTo -> mainInfoDettailTo.getAdPosition() == 2).subscribe(mainInfoDettailTo1 -> Picasso.with(getThisContext()).load(MainApp.getPicassoImagePath(mainInfoDettailTo1.getPicUrl())).into(sellingOne));
        Observable.from(adList).filter(mainInfoDettailTo -> mainInfoDettailTo.getAdPosition() == 3).subscribe(mainInfoDettailTo1 -> Picasso.with(getThisContext()).load(MainApp.getPicassoImagePath(mainInfoDettailTo1.getPicUrl())).into(sellingThree));
        findViewById(R.id.adLayout).setVisibility(View.VISIBLE);
    }

    public void addMenu() {
        NewShopApi api = ApiClientBulk.create(NewShopApi.class);
        api.getMainPageInfo("2", mUserHelperBulk.getUserInfoTo().getApartmentSid(), new HttpCallback<MessageTo<MainInfoTo>>(this) {
            @Override
            public void success(MessageTo<MainInfoTo> msg, Response response) {
                if (msg.getSuccess() == 0) {
                  //  msg.getData().getList().addAll(msg.getData().getList());
                    setMenuView(msg.getData().getList());

                }
            }

            @Override
            public void failure(RetrofitError error) {
            }
        });
    }

    public void setMenuView(List<MainInfoDettailTo> infoList) {
if (infoList.size()==0){
    return;
}
        if(infoList.size()<2){
            for (int i = 0; i <infoList.size()+1; i++) {
                View childView = View.inflate(getThisContext(), R.layout.menu_view_item, null);
                ImageView image = (ImageView) childView.findViewById(R.id.propertyBulk);
                if (i==0) {
                    Picasso.with(getThisContext()).load(MainApp.getPicassoImagePath(infoList.get(i).getPicUrl())).into(image);
                    //    Picasso.with(getThisContext()).load(R.drawable.property_load_icon).into(image);
                    childView.setOnClickListener(view -> {
                        Intent intent2 = new Intent(getThisContext(), ShopBulkActivity.class);
                        startActivity(intent2);
                        goToAnimation(1);
                    });
                } else {
                    Picasso.with(getThisContext()).load(R.drawable.property_load_icon).into(image);
                }
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                layoutParams.height = ViewPagerCompat.LayoutParams.WRAP_CONTENT;
                layoutParams.width = (int) (getScreenWidth() * 0.5);
                childView.setLayoutParams(layoutParams);
                menuLayout.addView(childView);
            }
        }
        else{
            for (int i = 0; i <infoList.size(); i++) {
                View childView = View.inflate(getThisContext(), R.layout.menu_view_item, null);
                ImageView image = (ImageView) childView.findViewById(R.id.propertyBulk);
                if (i==0&&infoList.get(i).getMenuType()==0) {
                    Picasso.with(getThisContext()).load(MainApp.getPicassoImagePath(infoList.get(i).getPicUrl())).into(image);
                    //    Picasso.with(getThisContext()).load(R.drawable.property_load_icon).into(image);
                    childView.setOnClickListener(view -> {
                        Intent intent2 = new Intent(getThisContext(), ShopBulkActivity.class);
                        startActivity(intent2);
                        Log.i("1111", "a");
                        goToAnimation(1);
                    });
                } else {
                    Picasso.with(getThisContext()).load(MainApp.getPicassoImagePath(infoList.get(i).getPicUrl())).into(image);
                    childView.setTag(infoList.get(i));
                    Log.i("1111", "b");
                    childView.setOnClickListener(view -> adJump((MainInfoDettailTo) childView.getTag()));
                }
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                layoutParams.height = ViewPagerCompat.LayoutParams.WRAP_CONTENT;
                layoutParams.width = (int) (getScreenWidth() * 0.5);
                childView.setLayoutParams(layoutParams);
                menuLayout.addView(childView);
            }
        }
        }


    public void adJump(MainInfoDettailTo info) {

        if (info != null && info.getForwardType() != 0) {
            if (info.getForwardType() == 1) {
                if (info.getInsideForwordType() != 0) {
                    Intent intent = null;
                    if (info.getInsideForwordType() == 1) {
                        intent = new Intent(getThisContext(), MerchantShopActivity.class);
                        intent.putExtra("ShopSid", info.getInsideForwordId() + "");
                        intent.putExtra("ShopName",info.getLayoutName());
                    } else if (info.getInsideForwordType() == 2) {
                        intent = new Intent(getThisContext(), ShopMoreType.class);
                        CategoryTo categoryTo = new CategoryTo();
                        categoryTo.setName(info.getLayoutName());
                        categoryTo.setId(info.getInsideForwordId() + "");
                        intent.putExtra("category", categoryTo);

                    } else if (info.getInsideForwordType() == 3) {
                        intent = new Intent(getThisContext(), GoodsDetailActivity.class);
                        intent.putExtra("GoodsSid", info.getInsideForwordId() + "");
                    } else if (info.getInsideForwordType() == 4) {
                        intent = new Intent(getThisContext(), OtherBulkActivity.class);
                        intent.putExtra("GroupId", info.getInsideForwordId() + "");
                        intent.putExtra("title", info.getLayoutName());
                    }
                    if (intent != null) {
                        startActivity(intent);
                        goToAnimation(1);
                    }
                }

            } else if (info.getForwardType() == 2) {
                Intent intent = new Intent(getThisContext(), ShopAdActivity.class);
                intent.putExtra("urlTitle", info.getLayoutName());
                intent.putExtra("shopUrl", info.getForwardUrl());
                startActivity(intent);
                goToAnimation(1);
            } else if (info.getForwardType() == 3) {
                Intent intent = new Intent(getThisContext(), PictureTextActivity.class);
                intent.putExtra("id", info.getId());
                intent.putExtra("title", info.getLayoutName());
                startActivity(intent);
                goToAnimation(1);
            }

        }
    }

    public void setShopList() {
        for (int i = 0; i < shopList.size(); i++) {
            if (i != 2) {
                for (int j = 0; j < 5; j++) {
                    shopList.get(i).getGoodsApiVolist().add(shopList.get(i).getGoodsApiVolist().get(0));
                }
            } else {
                for (int j = 0; j < 5; j++) {
                    shopList.get(i).getGoodsApiVolist().add(shopList.get(i).getGoodsApiVolist().get(1));
                }
            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        if (carNumber!=null)
            CarNumberUtil.getCarNumber(mUserHelperBulk.getSid(),getThisContext(),carNumber);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        autoRow.stopTurning();
    }
}
