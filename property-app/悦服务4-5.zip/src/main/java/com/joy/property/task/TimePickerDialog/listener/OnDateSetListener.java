package com.joy.property.task.TimePickerDialog.listener;


import com.joy.property.task.TimePickerDialog.TimePickerDialog;

/**
 * Created by jzxiang on 16/4/20.
 */
public interface OnDateSetListener {

    void onDateSet(TimePickerDialog timePickerView, long millseconds);
}
