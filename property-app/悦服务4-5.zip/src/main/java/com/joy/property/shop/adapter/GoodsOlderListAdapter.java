package com.joy.property.shop.adapter;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jinyi.ihome.module.newshop.CarGoodsInfo;
import com.joy.property.MainApp;
import com.joy.property.R;
import com.joy.property.common.adapter.ModeListAdapter;
import com.squareup.picasso.Picasso;

/**
 * Created by xz on 2016/7/12.
 **/
public class GoodsOlderListAdapter extends ModeListAdapter<CarGoodsInfo>{
    private Context mContext;
    public GoodsOlderListAdapter(Context context) {
        super(context);
        this.mContext = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        ShoppingCarHolder holder;

        if (row == null) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            row = inflater.inflate(R.layout.goods_list_item, null);
            holder = new ShoppingCarHolder(row);
            row.setTag(holder);
        } else {
            holder = (ShoppingCarHolder) row.getTag();
        }

        CarGoodsInfo mode=mList.get(position);
  if(mode!=null) {

        if (position==mList.size()-1)
            holder.getDivideLine().setVisibility(View.GONE);
        else
        holder.getDivideLine().setVisibility(View.VISIBLE);
        holder.getRl().setVisibility(View.GONE);
        holder.getGoodInfo().setVisibility(View.VISIBLE);
        Picasso.with(mContext).load(MainApp.getPicassoImagePath(mode.getPicUrl())).into(holder.getGoodsImage());
        holder.getGoodsName().setText(mode.getGoodsName());
        holder.getGoodsNumber().setText("x"+mode.getGoodsNum());

            holder.getPrice().setVisibility(View.VISIBLE);
            holder.getPrice().setText("¥ " + mode.getCurrentPrice());
            holder.getPrimePrice().setVisibility(View.VISIBLE);
            holder.getPrimePrice().setText("¥ " + mode.getRetailPrice());
            holder.getPrimePrice().setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            holder.getDiscount().setVisibility(View.VISIBLE);
      if ("团购".equals(mode.getIsGroup())){
          if (mode.getDiscountPercentage()<100)
              holder.getDiscount().setVisibility(View.VISIBLE);
          else
              holder.getDiscount().setVisibility(View.GONE);
          holder.getDiscount().setText((float)(mode.getDiscountPercentage()/10) + "折");
      }else
          holder.getDiscount().setVisibility(View.GONE);
            holder.getGoodsSelect().setVisibility(View.VISIBLE);
            holder.getCanUse().setVisibility(View.GONE);


            if (mode.getDistributionCost() > 0) {
                holder.getTrafficExpense().setText("配送费：¥ " + mode.getDistributionCost() + "");
            } else
                holder.getTrafficExpense().setText("免运费");
            holder.getCarNumber().setText(mode.getGoodsNum() + "");

        }





        return row;
    }

}
