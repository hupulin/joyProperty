package com.joy.property.shop.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.jinyi.ihome.module.newshop.CouponTo;
import com.joy.library.utils.DateUtil;
import com.joy.property.R;
import com.joy.property.common.adapter.ModeListAdapter;

/**
 * Created by xz on 2016/7/12.
 **/
public class MyCouponAdapter extends ModeListAdapter<CouponTo> {
    private Context mContext;
private int type;
    public MyCouponAdapter(Context context,int type) {
        super(context);
        this.mContext = context;
        this.type=type;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        MyCouponHolder holder;

        if (row == null) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            row = inflater.inflate(R.layout.my_coupon_item, null);
            holder = new MyCouponHolder(row);
            row.setTag(holder);
        } else {
            holder = (MyCouponHolder) row.getTag();
        }

        CouponTo mode = mList.get(position);
        if (mode != null) {
            holder.getUseRange().setText("使用范围："+mode.getCanUsegoodsName());
            holder.getUseCondition().setText("使用限制："+(mode.getUseRule()==0?"无限制":"满"+mode.getConsumptionAmount()+"元使用"));
            holder.getUseTime().setText("使用时间："+DateUtil.getDateString(mode.getActivityStartTime(),"yyyy.MM.dd")+"-"+DateUtil.getDateString(mode.getActivityEndTime(), "yyyy.MM.dd"));
            holder.getCouponAmount().setText(mode.getDiscountAmount()+"");
          if(type==0){
              holder.getAmountLayout().setBackgroundResource(R.drawable.coupon_right_un_use_bg);
          }else
              holder.getAmountLayout().setBackgroundResource(R.drawable.coupon_right_use_bg);
        }
        return row;
    }
}
