package com.joy.property.shop.fragment;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Toast;

import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.jinyi.ihome.infrastructure.MessageTo;
import com.jinyi.ihome.module.newshop.ShopListDetailTo;
import com.jinyi.ihome.module.purchase.GroupPurchaseTo;
import com.joy.common.api.ApiClient;
import com.joy.common.api.HttpCallback;
import com.joy.common.api.NewShopApi;
import com.joy.library.utils.HtmlUtil;
import com.joy.property.R;
import com.joy.property.base.BaseFragment;

import java.util.ArrayList;
import java.util.List;

import retrofit.RetrofitError;
import retrofit.client.Response;


@SuppressLint("ValidFragment")
public class GoodsDetailFragment extends BaseFragment {

    private WebView webView;
    private ScrollView scrollView;
public GoodsDetailFragment(ScrollView scrollView){
    this.scrollView=scrollView;
}
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
         View mRootView   = inflater.inflate(R.layout.fragment_goods_detail, container, false);

        findById(mRootView);

         setWebView();


        return mRootView;


    }


    private void findById(View view) {
        webView = (WebView) view.findViewById(R.id.webView);
        View unListView = view.findViewById(R.id.un_listView);
        unListView.setFocusable(true);
        unListView.setFocusableInTouchMode(true);
        webView.requestFocus();
      //  scrollView.post(() -> scrollView.scrollTo(0, 0));
//        webView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View v, boolean hasFocus) {
//                Toast.makeText(getThisContext(),hasFocus+"jiaod",Toast.LENGTH_LONG).show();
//                scrollView.post(() -> scrollView.scrollTo(0, 0));
//            }
//        });
    }



    private void setWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        String html = String.format("<html><head><style>img{max-width:100%%;height:auto !important;width:auto !important;};</style></head><body style='margin:0; padding:0;'>%s</body></html>",
                "");

        webSettings.setDefaultTextEncodingName("UTF-8");
        webView.loadDataWithBaseURL(null, HtmlUtil.formatHtml(html), "text/html", "UTF-8", null);
    }




    @Override
    protected Context getThisContext() {
        return getActivity();
    }
}
