package com.joy.property.common.adapter;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bm.library.PhotoView;
import com.joyhome.nacity.app.MainApp;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.List;

/**
 * Created by Admin on 2015-05-14
 */
public class LongImagePagerAdapter extends PagerAdapter {

    private List<String> mList;

    public LongImagePagerAdapter(List<String> list) {
        this.mList = list;
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {

        return view == object;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);

    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {


            PhotoView view = new PhotoView(container.getContext());
            view.enable();
            view.setScaleType(ImageView.ScaleType.FIT_CENTER);
            Picasso.with(container.getContext()).load(MainApp.getImagePath(mList.get(position))).into(new Target() {
                @Override
                public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                   if(bitmap.getHeight()/bitmap.getWidth()>=2)
                       view.setScaleType(ImageView.ScaleType.FIT_START);
                    view.setImageBitmap(bitmap);
                }

                @Override
                public void onBitmapFailed(Drawable drawable) {

                }

                @Override
                public void onPrepareLoad(Drawable drawable) {

                }
            });
            container.addView(view);


        return  view;
    }
}
