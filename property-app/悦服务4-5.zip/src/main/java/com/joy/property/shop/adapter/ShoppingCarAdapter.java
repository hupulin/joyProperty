package com.joy.property.shop.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.jinyi.ihome.module.newshop.CarGoodsInfo;
import com.joy.property.MainApp;
import com.joy.property.R;
import com.joy.property.common.adapter.ModeListAdapter;
import com.joy.property.shop.GoodsDetailActivity;
import com.joy.property.shop.InvalidGoodsActivity;
import com.squareup.picasso.Picasso;

/**
 * Created by xz on 2016/7/12.
 **/
public class ShoppingCarAdapter extends ModeListAdapter<CarGoodsInfo>{
    private Context mContext;
    private Activity activity;
    public ShoppingCarAdapter(Context context,Activity activity) {
        super(context);
        this.mContext = context;
        this.activity=activity;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        ShoppingCarHolder holder;

        if (row == null) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            row = inflater.inflate(R.layout.shopping_car_item, null);
            holder = new ShoppingCarHolder(row);
            row.setTag(holder);
        } else {
            holder = (ShoppingCarHolder) row.getTag();
        }

        CarGoodsInfo mode=mList.get(position);
if(mode!=null) {

    if (!TextUtils.isEmpty(mode.getMerchantNameTop()) || !TextUtils.isEmpty(mode.getStoresNameTop())) {
        holder.getRl().setVisibility(View.VISIBLE);
        holder.getGoodInfo().setVisibility(View.GONE);
        holder.getStoreName().setText(mode.getStoresNameTop());
        if (mode.isShopSelect())
            holder.getShopSelect().setBackgroundResource(R.drawable.shopping_car_select);
        else
            holder.getShopSelect().setBackgroundResource(R.drawable.shopping_car_circle);
        holder.getSelectStoreLayout().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mode.isShopSelect()) {
                    mode.setIsShopSelect(false);
                    if (shopSelectListener != null)
                        shopSelectListener.shopAllSelect(false, mode.getMerchantId());
                    holder.getShopSelect().setBackgroundResource(R.drawable.shopping_car_circle);
                } else {
                    mode.setIsShopSelect(true);
                    if (shopSelectListener != null)
                        shopSelectListener.shopAllSelect(true, mode.getMerchantId());
                    holder.getShopSelect().setBackgroundResource(R.drawable.shopping_car_select);
                }
            }
        });
        holder.getCoupons().setTag(mode);
holder.getGetCouponLayout().setOnClickListener(view -> {
    if (couponListener!=null)
        couponListener.getCoupon((CarGoodsInfo) holder.getCoupons().getTag());
});




    } else {
//        holder.getGoodInfo().setOnClickListener(view1 -> {
//            if ("正常".equals(mode.getIsInvalid())) {
//                             Intent intent = new Intent(mContext, GoodsDetailActivity.class);
//                             intent.putExtra("GoodsSid", mode.getGoodsId());
//                             mContext.startActivity(intent);
//                         } else {
//                             mContext.startActivity(new Intent(mContext, InvalidGoodsActivity.class));
//                         }
//            activity. overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);;
//        });
        if (mode.isNoLine())
            holder.getDivideLine().setVisibility(View.GONE);
        else
        holder.getDivideLine().setVisibility(View.VISIBLE);
        holder.getRl().setVisibility(View.GONE);
        holder.getGoodInfo().setVisibility(View.VISIBLE);
        Picasso.with(mContext).load(MainApp.getPicassoImagePath(mode.getPicUrl())).into(holder.getGoodsImage());
        holder.getGoodsName().setText(mode.getGoodsName());
        holder.getDisableClick().setOnClickListener(view -> System.out.println());
        if ("正常".equals(mode.getIsInvalid())) {
            holder.getPrice().setVisibility(View.VISIBLE);
            holder.getPrice().setText("¥" + mode.getCurrentPrice());
            holder.getPrimePrice().setVisibility(View.VISIBLE);
            holder.getPrimePrice().setText("¥" + mode.getRetailPrice());
            holder.getPrimePrice().setPaintFlags(Paint.STRIKE_THRU_TEXT_FLAG);
            holder.getDiscount().setVisibility(View.VISIBLE);
            holder.getCarAdd().setVisibility(View.VISIBLE);
            holder.getCarReduce().setVisibility(View.VISIBLE);
            holder.getCarNumber().setVisibility(View.VISIBLE);
            if ("团购".equals(mode.getIsGroup())){
                if (mode.getDiscountPercentage()<100)
                    holder.getDiscount().setVisibility(View.VISIBLE);
                else
                    holder.getDiscount().setVisibility(View.GONE);
                holder.getDiscount().setText((float)(mode.getDiscountPercentage()/10) + "折");
            }else
            holder.getDiscount().setVisibility(View.GONE);

            holder.getGoodsSelect().setVisibility(View.VISIBLE);
            holder.getCanUse().setVisibility(View.GONE);

            if (mode.isSelect()) {
                holder.getGoodsSelect().setImageResource(R.drawable.shopping_car_select);
            } else {
                holder.getGoodsSelect().setImageResource(R.drawable.shopping_car_circle);
            }
            if (mode.getDistributionCost() > 0) {
                holder.getTrafficExpense().setText("配送费：¥ " + mode.getDistributionCost() + "");
            } else
                holder.getTrafficExpense().setText("免运费");
            holder.getGoodsNumber().setVisibility(View.GONE);
            holder.getCarNumber().setText(mode.getGoodsNum() + "");
            holder.getCarAdd().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (Integer.valueOf(holder.getCarNumber().getText().toString()) < mode.getMaxSalesNum()&&Integer.valueOf(holder.getCarNumber().getText().toString())<mode.getNum()) {
                        holder.getCarNumber().setText(Integer.valueOf(holder.getCarNumber().getText().toString()) + 1 + "");
                  if (listener!=null)
                      listener.changeGoodsNumber(mode.getGoodsId(),holder.getCarNumber().getText().toString(),position,true,mode);
                    } else
                        Toast.makeText(mContext, "您已超出购买限制", Toast.LENGTH_LONG).show();

                }

            });
            holder.getCarReduce().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (Integer.valueOf(holder.getCarNumber().getText().toString())>mode.getMinSalesNum()){
                        holder.getCarNumber().setText(Integer.valueOf(holder.getCarNumber().getText().toString())-1+"");
                        if (listener!=null)
                            listener.changeGoodsNumber(mode.getGoodsId(),holder.getCarNumber().getText().toString(),position,false,mode);
                    }

                }
            });
        } else {
            holder.getTrafficExpense().setText("宝贝卖完了");
            holder.getPrice().setVisibility(View.GONE);
            holder.getPrimePrice().setVisibility(View.GONE);
            holder.getDiscount().setVisibility(View.GONE);
            holder.getCanUse().setVisibility(View.VISIBLE);
            holder.getCarAdd().setVisibility(View.GONE);
            holder.getCarReduce().setVisibility(View.GONE);
            holder.getCarNumber().setVisibility(View.GONE);
            holder.getGoodsSelect().setVisibility(View.GONE);
            holder.getGoodsNumber().setVisibility(View.VISIBLE);
            holder.getGoodsNumber().setText("x " + mode.getGoodsNum() + "");
        }
        holder.getSelectGoodsLayout().setOnClickListener(v -> {


            if (mode.isSelect()) {


                holder.getGoodsSelect().setImageResource(R.drawable.shopping_car_circle);
                mode.setIsSelect(false);
                if (listener != null)
                    pucchaselistener.purchaseNumberChange(false, position, mode);
            } else {
                holder.getGoodsSelect().setImageResource(R.drawable.shopping_car_select);
                mode.setIsSelect(true);
                if (listener != null)
                    pucchaselistener.purchaseNumberChange(true, position, mode);
            }
        });

    }
}


        return row;
    }
    private ShopCarChangeListener listener;
    private PurchaseChangeListener pucchaselistener;
    public void setPurchaseNumberChangeListener(PurchaseChangeListener listener){
        this.pucchaselistener=listener;
    }
    public void setChangeGoodsListener(ShopCarChangeListener listener){
        this.listener=listener;
    }
    public interface ShopCarChangeListener {

        void changeGoodsNumber(String goodsId,String number,int position,boolean isAdd,CarGoodsInfo mode);
    }
    public interface PurchaseChangeListener {
        void purchaseNumberChange(Boolean select, int position,CarGoodsInfo goodsTo);

    }
    private ShopAllSelectListener shopSelectListener;
    public interface ShopAllSelectListener {
        void shopAllSelect(Boolean select, String merchantId);

    }
    public void setShopAllSelect(ShopAllSelectListener listener){
        this.shopSelectListener=listener;
    }
    private CouponListener couponListener;

    public interface CouponListener {
        void getCoupon(CarGoodsInfo goodsTo);

    }
    public void setGetCoupon(CouponListener listener){
        this.couponListener=listener;
    }
}
