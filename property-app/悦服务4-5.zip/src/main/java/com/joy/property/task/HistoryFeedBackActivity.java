package com.joy.property.task;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.joy.common.widget.UploadImage;
import com.joy.property.R;

import com.jinyi.ihome.module.home.ServiceHistTo;
import com.joy.library.utils.DateUtil;
import com.joy.property.base.BaseActivity;
import com.joy.property.common.PictureShowActivity;
import com.wefika.flowlayout.FlowLayout;

public class HistoryFeedBackActivity extends BaseActivity implements
		OnClickListener {
	private TextView mDate;
	private TextView mTime;
	private TextView mContent;
    private ServiceHistTo  serviceHistTo;
    private FlowLayout  flowLayout;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_history_feedback);
		findById();
		initIntentDatas();
		initDatas();
	}

	private void findById() {
        findViewById(R.id.back).setOnClickListener(this);
		mTime = (TextView) findViewById(R.id.time);
		mDate = (TextView) findViewById(R.id.date);
		mContent =(TextView) findViewById(R.id.content);
        flowLayout = (FlowLayout) findViewById(R.id.flowLayout);

	}

	private void initIntentDatas() {
     serviceHistTo = (ServiceHistTo) getIntent().getSerializableExtra("mode");
	}

	private void initDatas() {
        if (serviceHistTo.getCreatedOn() != null) {
            mDate.setText(DateUtil.getDateTimeFormat(DateUtil.mFormatDateString, serviceHistTo.getCreatedOn()));
            mTime.setText(DateUtil.getDateTimeFormat(DateUtil.mTimeFormat, serviceHistTo.getCreatedOn()));
        }
        if (!TextUtils.isEmpty(serviceHistTo.getReplyDesc())) {
            mContent.setText(serviceHistTo.getReplyDesc());
        }

        if (!TextUtils.isEmpty(serviceHistTo.getReplyImages())) {
            String[] path = serviceHistTo.getReplyImages().split(";");
            int W = getScreenWidthPixels(this) - 50;
            FlowLayout.LayoutParams params = new FlowLayout.LayoutParams(W / 4, W / 4);
            params.leftMargin = 10;
            params.topMargin = 10;

            for (String  p : path) {
                ImageView image = new ImageView(this);
                image.setScaleType(ImageView.ScaleType.FIT_XY);
                displayImage(image ,p);
                image.setTag(serviceHistTo.getReplyImages());
                flowLayout.addView(image, flowLayout.getChildCount(), params);
                image.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getThisContext(),PictureShowActivity.class);
                        intent.putExtra("path",(String)v.getTag());
                        startActivity(intent);
                    }
                });

            }
        }
    }

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.back:
			onBackPressed();
			break;
           default:
               break;
		}
	}

    @Override
    protected Context getThisContext() {
        return HistoryFeedBackActivity.this;
    }

    @Override
    protected String toPageName() {
        return "历史反馈";
    }
}
