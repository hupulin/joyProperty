package com.joy.property.utils;

/**
 * Created by Administrator on 2016/3/24.
 */
public class NeighborService {
    private int  todaycomment;
    private int  count;
    private int  todaycount;

    public int getTodaycomment() {
        return todaycomment;
    }

    public void setTodaycomment(int todaycomment) {
        this.todaycomment = todaycomment;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getTodaycount() {
        return todaycount;
    }

    public void setTodaycount(int todaycount) {
        this.todaycount = todaycount;
    }
}
