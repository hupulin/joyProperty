package com.joyhome.nacity.app.photo.util;


import android.app.Activity;

import java.util.ArrayList;



public class PublicWay {
	public final static ArrayList<Activity> activityList = new ArrayList<>();
	
}
